<h1>
    Reset password
</h1>
<a href="{{ $url }}">Reset</a>
